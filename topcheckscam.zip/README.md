# topcheckscam — Starter website

This is a simple starter full-stack project (Node.js + Express + SQLite) for a website called **topcheckscam**.
It includes:
- public/ - static frontend (landing + admin panel)
- server.js - Express server with simple session auth and APIs
- db.sqlite - (created at runtime)
- package.json - dependencies

## Features included
- Admin login (session-based).
- Admin can add / edit / remove **giao dịch viên** (transaction officers).
- Public can submit scam reports.
- Simple UI (you can extend it).

## Default admin credentials (please change after first login)
- email: admin@topcheckscam.local
- password: ChangeMe123

## How to run (locally)
1. Install Node.js (>=16)
2. In project folder run:
   ```
   npm install
   node server.js
   ```
3. Visit http://localhost:3000

## Notes
This is a starter template. For production, you must:
- Use HTTPS
- Use secure session store (not in-memory)
- Change default password and use environment variables
- Add input validation and rate limiting
