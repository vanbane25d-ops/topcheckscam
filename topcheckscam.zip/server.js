const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bodyParser = require('body-parser');
const session = require('express-session');
const bcrypt = require('bcrypt');
const path = require('path');
const fs = require('fs');

const DB_FILE = path.join(__dirname, 'db.sqlite');
const app = express();
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
  secret: 'replace_this_secret_in_prod',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 1000*60*60*4 } // 4 hours
}));

// Initialize DB if missing
const initDb = () => {
  const exists = fs.existsSync(DB_FILE);
  const db = new sqlite3.Database(DB_FILE);
  db.serialize(() => {
    if (!exists) {
      db.run(`CREATE TABLE admins (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT UNIQUE,
        password_hash TEXT
      )`);
      db.run(`CREATE TABLE officers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        phone TEXT,
        email TEXT,
        note TEXT,
        approved INTEGER DEFAULT 0,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
      )`);
      db.run(`CREATE TABLE reports (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT,
        url TEXT,
        description TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
      )`);
      // default admin
      const bcrypt = require('bcrypt');
      const pwd = 'ChangeMe123';
      const salt = bcrypt.genSaltSync(10);
      const hash = bcrypt.hashSync(pwd, salt);
      db.run('INSERT INTO admins (email, password_hash) VALUES (?, ?)', ['admin@topcheckscam.local', hash]);
      console.log('Database initialized with default admin (admin@topcheckscam.local / ChangeMe123)');
    }
  });
  return db;
};

const db = initDb();

// --- Auth middleware
function requireAdmin(req, res, next) {
  if (req.session && req.session.adminId) return next();
  res.status(401).json({ error: 'Unauthorized' });
}

// --- Routes
app.post('/api/login', (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'Missing' });
  db.get('SELECT * FROM admins WHERE email = ?', [email], (err, row) => {
    if (err) return res.status(500).json({ error: 'DB error' });
    if (!row) return res.status(401).json({ error: 'Invalid' });
    bcrypt.compare(password, row.password_hash, (err, ok) => {
      if (ok) {
        req.session.adminId = row.id;
        req.session.adminEmail = row.email;
        res.json({ ok: true });
      } else res.status(401).json({ error: 'Invalid' });
    });
  });
});

app.post('/api/logout', (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

app.get('/api/admin/me', requireAdmin, (req, res) => {
  res.json({ email: req.session.adminEmail });
});

// Officers CRUD (only for admin)
app.get('/api/officers', requireAdmin, (req, res) => {
  db.all('SELECT * FROM officers ORDER BY created_at DESC', [], (err, rows) => {
    if (err) return res.status(500).json({ error: 'DB' });
    res.json(rows);
  });
});
app.post('/api/officers', requireAdmin, (req, res) => {
  const { name, phone, email, note } = req.body;
  db.run('INSERT INTO officers (name, phone, email, note, approved) VALUES (?, ?, ?, ?, 0)', [name, phone, email, note], function(err) {
    if (err) return res.status(500).json({ error: 'DB' });
    res.json({ id: this.lastID });
  });
});
app.put('/api/officers/:id', requireAdmin, (req, res) => {
  const id = req.params.id;
  const { name, phone, email, note, approved } = req.body;
  db.run('UPDATE officers SET name=?, phone=?, email=?, note=?, approved=? WHERE id=?', [name, phone, email, note, approved?1:0, id], function(err) {
    if (err) return res.status(500).json({ error: 'DB' });
    res.json({ changes: this.changes });
  });
});
app.delete('/api/officers/:id', requireAdmin, (req, res) => {
  const id = req.params.id;
  db.run('DELETE FROM officers WHERE id=?', [id], function(err) {
    if (err) return res.status(500).json({ error: 'DB' });
    res.json({ deleted: this.changes });
  });
});

// Public: submit a report
app.post('/api/reports', (req, res) => {
  const { title, url, description } = req.body;
  db.run('INSERT INTO reports (title, url, description) VALUES (?, ?, ?)', [title, url, description], function(err) {
    if (err) return res.status(500).json({ error: 'DB' });
    res.json({ id: this.lastID });
  });
});
app.get('/api/reports', requireAdmin, (req, res) => {
  db.all('SELECT * FROM reports ORDER BY created_at DESC', [], (err, rows) => {
    if (err) return res.status(500).json({ error: 'DB' });
    res.json(rows);
  });
});

// Serve admin panel UI (static file)
app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log('Server running on port', PORT);
});
